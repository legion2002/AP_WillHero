package com.example.ap_willhero;

public class Position {
    private float xPos;
    private float yPos;

    Position(float x, float y){
        this.xPos = x;
        this.yPos = y;

    }

    public float getxPos() {
        return xPos;
    }

    public void setxPos(float xPos) {
        this.xPos = xPos;
    }

    public float getyPos() {
        return yPos;
    }

    public void setyPos(float yPos) {
        this.yPos = yPos;
    }




}
