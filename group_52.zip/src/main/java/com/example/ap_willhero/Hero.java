package com.example.ap_willhero;

public class Hero {
    Position pos;

    Hero(){
        pos = new Position(55,55);
    }


}
